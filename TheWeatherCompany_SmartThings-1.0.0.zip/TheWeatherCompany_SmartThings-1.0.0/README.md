# TheWeatherCompany_SmartThings

Smartapp and device to automate things based on The Network Channel services provided through SmartThings API

<li>Import in your IDE the Smartapp and devicehandlers and publish the 2 for yourself</li>
<li>In the SmartApp menu of the Automation section in the mobile app, add The Weather Company Web Smartapp
<li> Setup the threshold and alerts you want to monitor</li>
<li> Select the switches you want to turn on or off upon the alert trigger</li>
<li> Enjoy localized weather alerts and automation!</li>
